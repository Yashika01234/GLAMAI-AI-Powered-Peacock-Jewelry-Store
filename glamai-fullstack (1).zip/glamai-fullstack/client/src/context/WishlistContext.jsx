import { createContext, useContext, useEffect, useState } from 'react';
import { useToast } from './ToastContext.jsx';

const WishlistContext = createContext(null);
const STORAGE_KEY = 'glamai_wishlist';

export function WishlistProvider({ children }) {
  const [wishlist, setWishlist] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    } catch {
      return [];
    }
  });
  const { showToast } = useToast();

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(wishlist));
  }, [wishlist]);

  const toggle = (productId) => {
    setWishlist((prev) => {
      const isIn = prev.includes(productId);
      showToast(isIn ? 'Removed from wishlist' : 'Added to wishlist');
      return isIn ? prev.filter((id) => id !== productId) : [...prev, productId];
    });
  };

  return (
    <WishlistContext.Provider value={{ wishlist, toggle }}>
      {children}
    </WishlistContext.Provider>
  );
}

export function useWishlist() {
  const ctx = useContext(WishlistContext);
  if (!ctx) throw new Error('useWishlist must be used inside a WishlistProvider');
  return ctx;
}
