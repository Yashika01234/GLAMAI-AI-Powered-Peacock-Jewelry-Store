import { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { api } from '../api.js';
import { useToast } from './ToastContext.jsx';

const CartContext = createContext(null);

export function CartProvider({ children }) {
  const [cart, setCart] = useState({ items: [], subtotal: 0, count: 0 });
  const [loading, setLoading] = useState(true);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const { showToast } = useToast();

  const refresh = useCallback(async () => {
    try {
      const data = await api.getCart();
      setCart(data);
    } catch (err) {
      console.error('Failed to load cart', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  const addItem = useCallback(async (product) => {
    try {
      const data = await api.addToCart(product.id, 1);
      setCart(data);
      showToast(`${product.name} added to your bag`);
    } catch (err) {
      showToast(err.message || 'Could not add item');
    }
  }, [showToast]);

  const changeQty = useCallback(async (productId, qty) => {
    try {
      const data = await api.updateCartQty(productId, qty);
      setCart(data);
    } catch (err) {
      showToast(err.message || 'Could not update quantity');
    }
  }, [showToast]);

  const removeItem = useCallback(async (productId) => {
    try {
      const data = await api.removeFromCart(productId);
      setCart(data);
    } catch (err) {
      showToast(err.message || 'Could not remove item');
    }
  }, [showToast]);

  const clear = useCallback(async () => {
    const data = await api.clearCart();
    setCart(data);
  }, []);

  const value = {
    cart, loading, drawerOpen,
    openDrawer: () => setDrawerOpen(true),
    closeDrawer: () => setDrawerOpen(false),
    addItem, changeQty, removeItem, clear, refresh,
  };

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart must be used inside a CartProvider');
  return ctx;
}
