// Colourways cycled across the catalogue. Index matches the `palette`
// field stored on each product in the database.
export const PALETTES = [
  { metal: '#E3C468', metalDeep: '#B4922F', gem: '#3FA98A', gem2: '#C24A63' }, // gold + emerald
  { metal: '#E3C468', metalDeep: '#B4922F', gem: '#C24A63', gem2: '#E3C468' }, // gold + ruby
  { metal: '#D8DEDD', metalDeep: '#8E9998', gem: '#2FB4B0', gem2: '#D8DEDD' }, // oxidised silver + turquoise
  { metal: '#E7B7A8', metalDeep: '#B4816F', gem: '#4B2A5C', gem2: '#E7B7A8' }, // rose gold + purple
  { metal: '#E3C468', metalDeep: '#B4922F', gem: '#F1E9D8', gem2: '#3FA98A' }, // gold + pearl
  { metal: '#D8DEDD', metalDeep: '#8E9998', gem: '#3FA98A', gem2: '#D8DEDD' }, // silver + emerald
  { metal: '#E3C468', metalDeep: '#B4922F', gem: '#2FA0C7', gem2: '#C24A63' }, // gold + blue
  { metal: '#E3C468', metalDeep: '#8E7A2F', gem: '#C24A63', gem2: '#3FA98A' }, // antique gold + multi
];
