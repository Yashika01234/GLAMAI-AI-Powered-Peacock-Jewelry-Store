import { Link } from 'react-router-dom';
import PeacockArt from './PeacockArt.jsx';
import { useCart } from '../context/CartContext.jsx';
import { useWishlist } from '../context/WishlistContext.jsx';

export default function ProductCard({ product }) {
  const { addItem, cart } = useCart();
  const { wishlist, toggle } = useWishlist();
  const isWished = wishlist.includes(product.id);
  const inCart = cart.items.find((i) => i.productId === product.id);

  return (
    <article className="product-card">
      <div className="product-media">
        <span className="badge-discount">{product.discountPct}% OFF</span>
        <button
          className={`badge-wish ${isWished ? 'active' : ''}`}
          aria-label="Wishlist"
          onClick={() => toggle(product.id)}
        >
          <svg viewBox="0 0 24 24" width="16" height="16" fill={isWished ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="1.8">
            <path d="M12 20.5s-7.5-4.6-10-9.3C0.4 7.8 2 4 6 4c2.3 0 3.9 1.4 6 4 2.1-2.6 3.7-4 6-4 4 0 5.6 3.8 4 7.2-2.5 4.7-10 9.3-10 9.3z" />
          </svg>
        </button>
        <Link to={`/product/${product.id}`} aria-label={product.name}>
          <PeacockArt palette={product.palette} variant={product.variant} id={product.id} />
        </Link>
      </div>
      <div className="product-info">
        <span className="product-cat">{product.category === 'oxidised' ? 'Oxidised Silver' : product.category}</span>
        <h3 className="product-name"><Link to={`/product/${product.id}`}>{product.name}</Link></h3>
        <div className="product-rating">
          {'★'.repeat(Math.round(product.rating))}{'☆'.repeat(5 - Math.round(product.rating))}
          <span style={{ color: 'var(--cream-dim)' }}> ({product.reviewCount})</span>
        </div>
        <div className="price-row">
          <span className="price-now">₹{product.price}</span>
          <span className="price-old">₹{product.origPrice}</span>
        </div>
        <button className={`add-cart-btn ${inCart ? 'added' : ''}`} onClick={() => addItem(product)}>
          {inCart ? `In Bag · ${inCart.qty}` : 'Add to Bag'}
        </button>
      </div>
    </article>
  );
}
