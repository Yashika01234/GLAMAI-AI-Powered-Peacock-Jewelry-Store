import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext.jsx';
import PeacockArt from './PeacockArt.jsx';

export default function CartDrawer() {
  const { cart, drawerOpen, closeDrawer, changeQty, removeItem } = useCart();

  return (
    <>
      <div className={`drawer-overlay ${drawerOpen ? 'open' : ''}`} onClick={closeDrawer} />
      <aside className={`cart-drawer ${drawerOpen ? 'open' : ''}`}>
        <div className="drawer-head">
          <h3>Your Bag</h3>
          <button className="drawer-close" onClick={closeDrawer}>&times;</button>
        </div>

        <div className="drawer-items">
          {cart.items.length === 0 ? (
            <p className="drawer-empty">Your bag is feeling light.<br />Add a feather or two ✦</p>
          ) : (
            cart.items.map((item) => (
              <div className="drawer-item" key={item.productId}>
                <div className="drawer-item-media">
                  <PeacockArt palette={item.palette} variant={item.variant} id={`cart-${item.productId}`} />
                </div>
                <div className="drawer-item-info">
                  <h5>{item.name}</h5>
                  <span className="price">₹{item.price}</span>
                  <div className="qty-control">
                    <button onClick={() => changeQty(item.productId, item.qty - 1)}>−</button>
                    <span>{item.qty}</span>
                    <button onClick={() => changeQty(item.productId, item.qty + 1)}>+</button>
                  </div>
                </div>
                <button className="remove-item" aria-label="Remove" onClick={() => removeItem(item.productId)}>&times;</button>
              </div>
            ))
          )}
        </div>

        <div className="drawer-footer">
          <div className="drawer-subtotal">
            <span>Subtotal</span>
            <strong>₹{cart.subtotal}</strong>
          </div>
          <Link
            to="/checkout"
            className="btn btn-primary btn-full"
            onClick={closeDrawer}
            style={{ pointerEvents: cart.items.length ? 'auto' : 'none', opacity: cart.items.length ? 1 : 0.5 }}
          >
            Checkout
          </Link>
          <p className="drawer-note">Free shipping on orders over ₹999</p>
        </div>
      </aside>
    </>
  );
}
