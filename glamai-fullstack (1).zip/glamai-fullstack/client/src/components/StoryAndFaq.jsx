const FAQ = [
  { title: 'What is Peacock Week?', body: "Peacock Week is our 7-day festive edit celebrating the peacock's iconic 'mor pankh' \u2014 jhumkas, chandbalis, studs and danglers, all peacock-inspired, all discounted." },
  { title: "What's the discount?", body: 'Everything in the Peacock Week edit is 40\u201360% off. The badge on each product card shows the exact discount for that piece.' },
  { title: 'Shipping & delivery', body: 'We offer free shipping on orders over \u20b9999. Below that, shipping is a flat \u20b979. Standard delivery takes 4\u20136 business days.' },
  { title: 'Returns & exchange', body: 'You can return or exchange any unworn piece within 7 days of delivery, in its original packaging, for a full refund or store credit.' },
  { title: 'Are these real gold?', body: 'Our pieces are crafted in brass and 92.5 silver with gold micron-plating or oxidised finishing, set with kundan, enamel work and cultured pearls.' },
];

export function StorySection() {
  return (
    <section className="story-section" id="story">
      <div className="story-inner">
        <div className="story-text">
          <p className="hero-eyebrow">The Feather Story</p>
          <h2>Why the peacock?</h2>
          <p>
            In Indian jewellery, the peacock's eye &mdash; the "mor pankh" &mdash; is worn as a mark of
            grace and renewal. Every piece in this edit borrows that same iridescent curve, reimagined
            across gold, oxidised silver and jewel-tone enamel.
          </p>
        </div>
        <div className="story-divider">
          <svg viewBox="0 0 200 60" width="100%" height="60">
            <path d="M0,30 Q50,0 100,30 T200,30" fill="none" stroke="url(#storyGrad)" strokeWidth="1.2" />
            <circle cx="100" cy="30" r="5" fill="none" stroke="url(#storyGrad)" strokeWidth="1.2" />
            <defs>
              <linearGradient id="storyGrad" x1="0" y1="0" x2="200" y2="0">
                <stop offset="0" stopColor="#D9B94A" />
                <stop offset="1" stopColor="#3FA98A" />
              </linearGradient>
            </defs>
          </svg>
        </div>
      </div>
    </section>
  );
}

export function FaqSection() {
  return (
    <section className="faq-section" id="faq">
      <p className="hero-eyebrow" style={{ textAlign: 'center' }}>Help</p>
      <h2 style={{ textAlign: 'center' }}>Quick Answers</h2>
      <div className="faq-grid">
        {FAQ.map((f) => (
          <div className="faq-item" key={f.title}>
            <h4>{f.title}</h4>
            <p>{f.body}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

export function FeatureStrip() {
  return (
    <section className="feature-strip">
      <div className="feature-item">
        <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M20 7 9 18l-5-5" /></svg>
        <span>Handcrafted Peacock Motifs</span>
      </div>
      <div className="feature-item">
        <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M3 12h18M3 6h18M3 18h18" /></svg>
        <span>Free Shipping over ₹999</span>
      </div>
      <div className="feature-item">
        <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" strokeWidth="1.5"><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 3" /></svg>
        <span>7-Day Easy Returns</span>
      </div>
      <div className="feature-item">
        <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M12 2 3 7v6c0 5 4 8 9 9 5-1 9-4 9-9V7z" /></svg>
        <span>Tarnish-Safe Plating</span>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="site-footer">
      <div className="footer-inner">
        <div className="logo footer-logo">
          <svg viewBox="0 0 40 40" width="28" height="28">
            <circle cx="20" cy="20" r="18" fill="none" stroke="#D9B94A" strokeWidth="1.4" />
            <circle cx="20" cy="20" r="7" fill="#D9B94A" />
          </svg>
          <span className="logo-text">Glam AI</span>
        </div>
        <p>Handcrafted peacock-inspired jewellery. Made-to-love, one feather at a time.</p>
        <p className="footer-copy">&copy; 2026 Glam AI Jewels &mdash; Full-stack demo storefront for Peacock Week.</p>
      </div>
    </footer>
  );
}
