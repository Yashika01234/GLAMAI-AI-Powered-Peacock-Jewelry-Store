import ProductCard from './ProductCard.jsx';

function SkeletonCard() {
  return (
    <div className="product-card skeleton-card">
      <div className="product-media skeleton-block" />
      <div className="product-info">
        <div className="skeleton-line" style={{ width: '40%' }} />
        <div className="skeleton-line" style={{ width: '80%' }} />
        <div className="skeleton-line" style={{ width: '50%' }} />
      </div>
    </div>
  );
}

export default function ProductGrid({ products, loading, error }) {
  if (error) {
    return (
      <div className="grid-message">
        <p>Couldn't load the catalogue: {error}</p>
        <p className="grid-message-sub">Is the API server running on port 4000?</p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="products-grid">
        {Array.from({ length: 8 }).map((_, i) => <SkeletonCard key={i} />)}
      </div>
    );
  }

  if (!products.length) {
    return (
      <div className="grid-message">
        <p>No feathers match this filter yet.</p>
      </div>
    );
  }

  return (
    <div className="products-grid">
      {products.map((p) => <ProductCard key={p.id} product={p} />)}
    </div>
  );
}
