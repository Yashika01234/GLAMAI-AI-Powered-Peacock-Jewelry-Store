import { forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react';
import { api } from '../api.js';

/**
 * The assistant's answers are entirely canned: the tree is fetched once
 * from GET /api/chat/nodes and then walked client-side. There is no call
 * out to any AI provider, so responses are instant, free, and predictable.
 */
const Chatbot = forwardRef(function Chatbot(_props, ref) {
  const [open, setOpen] = useState(false);
  const [badge, setBadge] = useState(true);
  const [tree, setTree] = useState(null);
  const [messages, setMessages] = useState([]);
  const [currentOptions, setCurrentOptions] = useState([]);
  const bodyRef = useRef(null);

  useImperativeHandle(ref, () => ({
    open: () => { setOpen(true); setBadge(false); },
  }));

  useEffect(() => {
    api.getChatNodes().then(setTree).catch(() => setTree(null));
  }, []);

  useEffect(() => {
    if (open && tree && messages.length === 0) {
      goTo('root');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, tree]);

  useEffect(() => {
    bodyRef.current?.scrollTo({ top: bodyRef.current.scrollHeight });
  }, [messages]);

  function goTo(key, userLabel) {
    const node = tree[key];
    if (!node) return;
    setMessages((prev) => [
      ...prev,
      ...(userLabel ? [{ who: 'user', text: userLabel }] : []),
      { who: 'bot', text: node.bot },
    ]);
    setCurrentOptions(node.options);
  }

  function toggle() {
    setOpen((o) => !o);
    setBadge(false);
  }

  return (
    <>
      <button className="chat-fab" aria-label="Open Glam AI Assistant" onClick={toggle}>
        <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <path d="M12 3a9 9 0 0 0-9 9 8.9 8.9 0 0 0 1.6 5.1L3 21l4.1-1.5A9 9 0 1 0 12 3z" />
          <circle cx="8.5" cy="12" r="1" fill="currentColor" stroke="none" />
          <circle cx="12" cy="12" r="1" fill="currentColor" stroke="none" />
          <circle cx="15.5" cy="12" r="1" fill="currentColor" stroke="none" />
        </svg>
        {badge && <span className="chat-fab-badge">1</span>}
      </button>

      <div className={`chat-window ${open ? 'open' : ''}`}>
        <div className="chat-head">
          <div className="chat-head-info">
            <div className="chat-avatar">
              <svg viewBox="0 0 40 40" width="26" height="26">
                <circle cx="20" cy="20" r="18" fill="none" stroke="#D9B94A" strokeWidth="1.4" />
                <circle cx="20" cy="20" r="7" fill="#D9B94A" />
              </svg>
            </div>
            <div>
              <strong>Glam AI</strong>
              <p>Peacock Week helper ✦ Online</p>
            </div>
          </div>
          <button className="drawer-close" onClick={() => setOpen(false)}>&times;</button>
        </div>

        <div className="chat-body" ref={bodyRef}>
          {!tree ? (
            <div className="msg msg-bot">Connecting to the API... make sure the server is running on port 4000.</div>
          ) : (
            messages.map((m, i) => (
              <div className={`msg msg-${m.who}`} key={i}>{m.text}</div>
            ))
          )}
        </div>

        <div className="chat-options">
          {currentOptions.map((opt) => (
            <button key={opt.next} className="chat-opt-btn" onClick={() => goTo(opt.next, opt.label)}>
              {opt.label}
            </button>
          ))}
        </div>
      </div>
    </>
  );
});

export default Chatbot;
