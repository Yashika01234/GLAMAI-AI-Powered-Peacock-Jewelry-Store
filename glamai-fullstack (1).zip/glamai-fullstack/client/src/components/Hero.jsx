import Countdown from './Countdown.jsx';
import PeacockArt from './PeacockArt.jsx';

export default function Hero({ onOpenChat }) {
  return (
    <section className="hero" id="collection">
      <div className="hero-glow" />
      <svg className="hero-feather-bg" viewBox="0 0 800 800" aria-hidden="true">
        <g opacity="0.16">
          <circle cx="400" cy="400" r="360" fill="none" stroke="#D9B94A" strokeWidth="1" />
          <circle cx="400" cy="400" r="260" fill="none" stroke="#3FA98A" strokeWidth="1" />
          <circle cx="400" cy="400" r="160" fill="none" stroke="#D9B94A" strokeWidth="1" />
        </g>
      </svg>

      <div className="hero-content">
        <p className="hero-eyebrow">The Mor Mela &nbsp;•&nbsp; 7 Days Only</p>
        <h1 className="hero-title">Peacock<br /><em>Week</em></h1>
        <p className="hero-sub">
          Seven days of iridescent jhumkas, chandbalis &amp; danglers &mdash; every plume, feather and
          emerald eye, up to <strong>60% off</strong>.
        </p>
        <div className="hero-cta-row">
          <a href="#shop" className="btn btn-primary">Shop the Feathers</a>
          <button className="btn btn-ghost" onClick={onOpenChat}>Ask Glam AI ✦</button>
        </div>
        <Countdown />
      </div>

      <div className="hero-earring-showcase" aria-hidden="true">
        <PeacockArt palette={0} variant="jhumka" id="hero" />
      </div>
    </section>
  );
}
