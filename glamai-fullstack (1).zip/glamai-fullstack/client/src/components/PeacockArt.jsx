import { PALETTES } from '../palettes.js';

/**
 * Renders a stylised peacock-feather earring as inline SVG.
 * Every product uses this instead of a product photo, so the whole
 * catalogue renders instantly with zero image assets and zero
 * licensing concerns.
 */
export default function PeacockArt({ palette = 0, variant = 'jhumka', id = 'p' }) {
  const { metal, metalDeep, gem, gem2 } = PALETTES[palette] || PALETTES[0];
  const uid = `g${id}`;

  const medallion = (
    <>
      <path
        d="M70,22 C42,22 28,46 37,74 C44,94 58,102 70,116 C82,102 96,94 103,74 C112,46 98,22 70,22 Z"
        fill={`url(#${uid}m)`} stroke={metalDeep} strokeWidth="1.2"
      />
      <circle cx="70" cy="58" r="16" fill={gem} opacity="0.9" />
      <circle cx="70" cy="58" r="9.5" fill={`url(#${uid}m)`} />
      <circle cx="70" cy="58" r="3.2" fill="#0B2A27" />
      <path d="M70,40 C60,46 58,58 62,66 M70,40 C80,46 82,58 78,66" fill="none" stroke={metalDeep} strokeWidth="1" />
      <circle cx="70" cy="15" r="3.2" fill={`url(#${uid}m)`} />
      <line x1="70" y1="15" x2="70" y2="22" stroke={metalDeep} strokeWidth="1.4" />
    </>
  );

  const domeBeads = (
    <>
      <path d="M48,118 A22,17 0 0 0 92,118 L92,131 A22,11 0 0 1 48,131 Z" fill={`url(#${uid}m)`} stroke={metalDeep} strokeWidth="1" />
      <line x1="55" y1="131" x2="55" y2="142" stroke={metalDeep} strokeWidth="1" />
      <circle cx="55" cy="146" r="3.6" fill={gem2} />
      <line x1="70" y1="131" x2="70" y2="148" stroke={metalDeep} strokeWidth="1" />
      <circle cx="70" cy="152" r="4.2" fill={gem} />
      <line x1="85" y1="131" x2="85" y2="142" stroke={metalDeep} strokeWidth="1" />
      <circle cx="85" cy="146" r="3.6" fill={gem2} />
    </>
  );

  const chainDrop = (
    <>
      <line x1="70" y1="116" x2="70" y2="140" stroke={metalDeep} strokeWidth="1.2" strokeDasharray="2 3" />
      <circle cx="70" cy="148" r="7" fill={`url(#${uid}m)`} stroke={metalDeep} strokeWidth="1" />
      <circle cx="70" cy="148" r="3" fill={gem} />
    </>
  );

  const crescent = (
    <>
      <path
        d="M46,70 C40,40 62,20 88,24 C68,28 54,46 58,68 C62,90 80,102 98,100 C82,116 52,108 46,70 Z"
        fill={`url(#${uid}m)`} stroke={metalDeep} strokeWidth="1.2"
      />
      <circle cx="60" cy="56" r="8" fill={gem} opacity="0.9" />
      <circle cx="60" cy="56" r="4" fill={metal} />
      <line x1="72" y1="98" x2="72" y2="112" stroke={metalDeep} strokeWidth="1.4" />
    </>
  );

  let body;
  if (variant === 'jhumka') body = <>{medallion}{domeBeads}</>;
  else if (variant === 'stud') body = medallion;
  else if (variant === 'dangler') body = <>{medallion}{chainDrop}</>;
  else if (variant === 'chandbali') body = <>{crescent}{domeBeads}</>;
  else body = <>{medallion}{domeBeads}</>;

  return (
    <svg viewBox="0 0 140 170" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id={`${uid}m`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor={metal} />
          <stop offset="1" stopColor={metalDeep} />
        </linearGradient>
      </defs>
      <g>{body}</g>
    </svg>
  );
}
