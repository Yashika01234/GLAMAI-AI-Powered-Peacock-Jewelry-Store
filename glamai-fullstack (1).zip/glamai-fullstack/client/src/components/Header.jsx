import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext.jsx';
import { useWishlist } from '../context/WishlistContext.jsx';
import { useToast } from '../context/ToastContext.jsx';

export default function Header() {
  const { cart, openDrawer } = useCart();
  const { wishlist } = useWishlist();
  const { showToast } = useToast();

  return (
    <>
      <div className="announce-bar">
        <div className="announce-track">
          {[0, 1].flatMap((i) => [
            <span key={`a${i}`}>✦ PEACOCK WEEK &mdash; UP TO 60% OFF ALL PEACOCK EARRINGS ✦</span>,
            <span key={`b${i}`}>✦ FREE SHIPPING OVER ₹999 ✦</span>,
            <span key={`c${i}`}>✦ 7 DAYS ONLY &mdash; THE MOR MELA IS HERE ✦</span>,
          ])}
        </div>
      </div>

      <header className="site-header">
        <div className="header-inner">
          <Link to="/" className="logo">
            <svg className="logo-mark" viewBox="0 0 40 40" width="34" height="34">
              <circle cx="20" cy="20" r="18" fill="none" stroke="url(#logoGrad)" strokeWidth="1.4" />
              <circle cx="20" cy="20" r="7" fill="url(#logoGrad)" />
              <circle cx="20" cy="20" r="2.4" fill="#0B2A27" />
              <defs>
                <linearGradient id="logoGrad" x1="0" y1="0" x2="40" y2="40">
                  <stop offset="0" stopColor="#D9B94A" />
                  <stop offset="1" stopColor="#3FA98A" />
                </linearGradient>
              </defs>
            </svg>
            <span className="logo-text">Glam AI</span>
          </Link>

          <nav className="main-nav">
            <Link to="/#shop">Peacock Week</Link>
            <Link to="/#story">The Feather Story</Link>
            <Link to="/#faq">Help</Link>
          </nav>

          <div className="header-actions">
            <button
              className="icon-btn"
              aria-label="Wishlist"
              onClick={() => showToast(wishlist.length ? `${wishlist.length} item(s) in your wishlist` : 'Your wishlist is empty')}
            >
              <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.6">
                <path d="M12 20.5s-7.5-4.6-10-9.3C0.4 7.8 2 4 6 4c2.3 0 3.9 1.4 6 4 2.1-2.6 3.7-4 6-4 4 0 5.6 3.8 4 7.2-2.5 4.7-10 9.3-10 9.3z" />
              </svg>
            </button>
            <button className="icon-btn" aria-label="Cart" onClick={openDrawer}>
              <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.6">
                <path d="M3 4h2l1.4 12.2A2 2 0 0 0 8.4 18H18a2 2 0 0 0 2-1.7L21 8H6" />
                <circle cx="9" cy="21" r="1.4" fill="currentColor" stroke="none" />
                <circle cx="18" cy="21" r="1.4" fill="currentColor" stroke="none" />
              </svg>
              <span className="cart-count">{cart.count}</span>
            </button>
          </div>
        </div>
      </header>
    </>
  );
}
