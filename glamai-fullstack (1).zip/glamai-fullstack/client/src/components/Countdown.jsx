import { useEffect, useState } from 'react';

const STORAGE_KEY = 'glamai_sale_end';

function getEndTime() {
  let end = localStorage.getItem(STORAGE_KEY);
  if (!end) {
    end = Date.now() + 7 * 24 * 60 * 60 * 1000;
    localStorage.setItem(STORAGE_KEY, String(end));
  }
  return Number(end);
}

function splitDiff(diffMs) {
  const diff = Math.max(0, diffMs);
  return {
    d: Math.floor(diff / 86400000),
    h: Math.floor((diff % 86400000) / 3600000),
    m: Math.floor((diff % 3600000) / 60000),
    s: Math.floor((diff % 60000) / 1000),
  };
}

export default function Countdown() {
  const [end] = useState(getEndTime);
  const [parts, setParts] = useState(() => splitDiff(end - Date.now()));

  useEffect(() => {
    const id = setInterval(() => setParts(splitDiff(end - Date.now())), 1000);
    return () => clearInterval(id);
  }, [end]);

  const pad = (n) => String(n).padStart(2, '0');

  return (
    <div className="countdown" aria-label="Sale ends in">
      <div className="cd-box"><span>{pad(parts.d)}</span><small>Days</small></div>
      <div className="cd-sep">:</div>
      <div className="cd-box"><span>{pad(parts.h)}</span><small>Hrs</small></div>
      <div className="cd-sep">:</div>
      <div className="cd-box"><span>{pad(parts.m)}</span><small>Min</small></div>
      <div className="cd-sep">:</div>
      <div className="cd-box"><span>{pad(parts.s)}</span><small>Sec</small></div>
    </div>
  );
}
