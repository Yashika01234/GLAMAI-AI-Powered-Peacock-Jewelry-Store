const CATEGORIES = [
  { value: 'all', label: 'All Feathers' },
  { value: 'jhumka', label: 'Jhumkas' },
  { value: 'chandbali', label: 'Chandbalis' },
  { value: 'stud', label: 'Studs' },
  { value: 'dangler', label: 'Danglers' },
  { value: 'oxidised', label: 'Oxidised Silver' },
];

export default function FilterBar({ category, onCategoryChange, sort, onSortChange }) {
  return (
    <section className="filter-strip" id="shop">
      <div className="filter-inner">
        <div className="filter-chips">
          {CATEGORIES.map((c) => (
            <button
              key={c.value}
              className={`chip ${category === c.value ? 'active' : ''}`}
              onClick={() => onCategoryChange(c.value)}
            >
              {c.label}
            </button>
          ))}
        </div>
        <div className="sort-wrap">
          <label htmlFor="sortSelect">Sort</label>
          <select id="sortSelect" value={sort} onChange={(e) => onSortChange(e.target.value)}>
            <option value="featured">Featured</option>
            <option value="discount">Biggest Discount</option>
            <option value="low">Price: Low to High</option>
            <option value="high">Price: High to Low</option>
          </select>
        </div>
      </div>
    </section>
  );
}
