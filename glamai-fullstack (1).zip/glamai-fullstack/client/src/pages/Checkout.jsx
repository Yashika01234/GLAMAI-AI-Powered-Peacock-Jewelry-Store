import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../api.js';
import { useCart } from '../context/CartContext.jsx';
import PeacockArt from '../components/PeacockArt.jsx';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PINCODE_RE = /^[0-9]{6}$/;

const FREE_SHIPPING_THRESHOLD = 999;
const SHIPPING_FEE = 79;

export default function Checkout() {
  const { cart, refresh } = useCart();
  const navigate = useNavigate();
  const [form, setForm] = useState({ customerName: '', email: '', address: '', city: '', pincode: '' });
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [serverError, setServerError] = useState(null);

  const shipping = cart.subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : SHIPPING_FEE;
  const total = cart.subtotal + shipping;

  function validate() {
    const e = {};
    if (!form.customerName.trim()) e.customerName = 'Please enter your name';
    if (!EMAIL_RE.test(form.email)) e.email = 'Enter a valid email address';
    if (!form.address.trim()) e.address = 'Please enter your address';
    if (!form.city.trim()) e.city = 'Please enter your city';
    if (!PINCODE_RE.test(form.pincode)) e.pincode = 'Enter a valid 6-digit pincode';
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  async function handleSubmit(ev) {
    ev.preventDefault();
    setServerError(null);
    if (!validate()) return;
    setSubmitting(true);
    try {
      const order = await api.checkout(form);
      await refresh();
      navigate(`/order/${order.id}`);
    } catch (err) {
      setServerError(err.message || 'Something went wrong placing your order.');
    } finally {
      setSubmitting(false);
    }
  }

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  if (cart.items.length === 0) {
    return (
      <div className="detail-message">
        <p>Your bag is empty, so there's nothing to check out yet.</p>
        <Link to="/" className="btn btn-primary">Browse Peacock Week</Link>
      </div>
    );
  }

  return (
    <section className="checkout-section">
      <h1>Checkout</h1>
      <div className="checkout-grid">
        <form className="checkout-form" onSubmit={handleSubmit} noValidate>
          <label>
            Full name
            <input value={form.customerName} onChange={(e) => update('customerName', e.target.value)} placeholder="Ananya Sharma" />
            {errors.customerName && <span className="field-error">{errors.customerName}</span>}
          </label>
          <label>
            Email
            <input value={form.email} onChange={(e) => update('email', e.target.value)} placeholder="you@example.com" />
            {errors.email && <span className="field-error">{errors.email}</span>}
          </label>
          <label>
            Address
            <input value={form.address} onChange={(e) => update('address', e.target.value)} placeholder="House no., street, area" />
            {errors.address && <span className="field-error">{errors.address}</span>}
          </label>
          <div className="field-row">
            <label>
              City
              <input value={form.city} onChange={(e) => update('city', e.target.value)} placeholder="Ghaziabad" />
              {errors.city && <span className="field-error">{errors.city}</span>}
            </label>
            <label>
              Pincode
              <input value={form.pincode} onChange={(e) => update('pincode', e.target.value)} placeholder="201001" />
              {errors.pincode && <span className="field-error">{errors.pincode}</span>}
            </label>
          </div>

          {serverError && <p className="field-error" style={{ marginTop: 4 }}>{serverError}</p>}

          <button className="btn btn-primary btn-full" type="submit" disabled={submitting}>
            {submitting ? 'Placing order…' : `Place Order · ₹${total}`}
          </button>
          <p className="drawer-note">This is a demo checkout. No real payment is processed.</p>
        </form>

        <aside className="checkout-summary">
          <h3>Order Summary</h3>
          {cart.items.map((item) => (
            <div className="summary-row" key={item.productId}>
              <div className="summary-media"><PeacockArt palette={item.palette} variant={item.variant} id={`sum-${item.productId}`} /></div>
              <div className="summary-info">
                <span>{item.name} &times; {item.qty}</span>
                <strong>₹{item.price * item.qty}</strong>
              </div>
            </div>
          ))}
          <div className="summary-total-row"><span>Subtotal</span><span>₹{cart.subtotal}</span></div>
          <div className="summary-total-row"><span>Shipping</span><span>{shipping === 0 ? 'Free' : `₹${shipping}`}</span></div>
          <div className="summary-total-row summary-grand"><span>Total</span><span>₹{total}</span></div>
        </aside>
      </div>
    </section>
  );
}
