import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { api } from '../api.js';
import PeacockArt from '../components/PeacockArt.jsx';
import { useCart } from '../context/CartContext.jsx';
import { useWishlist } from '../context/WishlistContext.jsx';

export default function ProductDetail() {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [error, setError] = useState(null);
  const [qty, setQty] = useState(1);
  const { addItem, cart, changeQty } = useCart();
  const { wishlist, toggle } = useWishlist();

  useEffect(() => {
    setProduct(null);
    setError(null);
    setQty(1);
    api.getProduct(id).then(setProduct).catch((err) => setError(err.message));
  }, [id]);

  if (error) {
    return (
      <div className="detail-message">
        <p>We couldn't find that piece: {error}</p>
        <Link to="/" className="btn btn-ghost">Back to the collection</Link>
      </div>
    );
  }
  if (!product) {
    return <div className="detail-message"><p>Loading…</p></div>;
  }

  const inCart = cart.items.find((i) => i.productId === product.id);
  const isWished = wishlist.includes(product.id);

  const handleAdd = async () => {
    for (let i = 0; i < qty; i++) {
      // eslint-disable-next-line no-await-in-loop
      await addItem(product);
    }
  };

  return (
    <section className="product-detail">
      <Link to="/" className="back-link">&larr; Back to Peacock Week</Link>
      <div className="detail-grid">
        <div className="detail-media">
          <span className="badge-discount">{product.discountPct}% OFF</span>
          <PeacockArt palette={product.palette} variant={product.variant} id={`detail-${product.id}`} />
        </div>
        <div className="detail-info">
          <span className="product-cat">{product.category === 'oxidised' ? 'Oxidised Silver' : product.category}</span>
          <h1>{product.name}</h1>
          <div className="product-rating">
            {'★'.repeat(Math.round(product.rating))}{'☆'.repeat(5 - Math.round(product.rating))}
            <span style={{ color: 'var(--cream-dim)' }}> ({product.reviewCount} reviews)</span>
          </div>
          <div className="price-row" style={{ margin: '14px 0' }}>
            <span className="price-now" style={{ fontSize: '1.6rem' }}>₹{product.price}</span>
            <span className="price-old">₹{product.origPrice}</span>
          </div>
          <p className="detail-desc">{product.description}</p>
          <p className="detail-stock">{product.stock > 0 ? `${product.stock} in stock` : 'Out of stock'}</p>

          <div className="detail-actions">
            <div className="qty-control detail-qty">
              <button onClick={() => setQty((q) => Math.max(1, q - 1))}>−</button>
              <span>{qty}</span>
              <button onClick={() => setQty((q) => q + 1)}>+</button>
            </div>
            <button className="btn btn-primary" onClick={handleAdd}>
              {inCart ? `Add More (In Bag · ${inCart.qty})` : 'Add to Bag'}
            </button>
            <button className={`btn btn-ghost wish-btn ${isWished ? 'active' : ''}`} onClick={() => toggle(product.id)}>
              {isWished ? '♥ Wishlisted' : '♡ Wishlist'}
            </button>
          </div>

          {inCart && (
            <div className="detail-cart-qty">
              <span>In your bag:</span>
              <div className="qty-control">
                <button onClick={() => changeQty(product.id, inCart.qty - 1)}>−</button>
                <span>{inCart.qty}</span>
                <button onClick={() => changeQty(product.id, inCart.qty + 1)}>+</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
