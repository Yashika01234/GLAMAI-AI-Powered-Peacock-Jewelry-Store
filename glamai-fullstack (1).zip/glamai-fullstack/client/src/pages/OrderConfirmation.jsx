import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { api } from '../api.js';

export default function OrderConfirmation() {
  const { id } = useParams();
  const [order, setOrder] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    api.getOrder(id).then(setOrder).catch((err) => setError(err.message));
  }, [id]);

  if (error) {
    return (
      <div className="detail-message">
        <p>We couldn't find that order: {error}</p>
        <Link to="/" className="btn btn-primary">Back home</Link>
      </div>
    );
  }
  if (!order) return <div className="detail-message"><p>Loading…</p></div>;

  return (
    <section className="confirmation-section">
      <div className="confirmation-card">
        <div className="confirmation-check">✦</div>
        <h1>Order confirmed</h1>
        <p className="confirmation-sub">Thank you, {order.customerName}. A confirmation would normally be emailed to {order.email}.</p>

        <div className="confirmation-id">Order ID: <code>{order.id}</code></div>

        <div className="confirmation-items">
          {order.items.map((item) => (
            <div className="summary-row" key={item.productId}>
              <span>{item.name} &times; {item.qty}</span>
              <strong>₹{item.price * item.qty}</strong>
            </div>
          ))}
        </div>

        <div className="summary-total-row"><span>Subtotal</span><span>₹{order.subtotal}</span></div>
        <div className="summary-total-row"><span>Shipping</span><span>{order.shipping === 0 ? 'Free' : `₹${order.shipping}`}</span></div>
        <div className="summary-total-row summary-grand"><span>Total paid</span><span>₹{order.total}</span></div>

        <div className="confirmation-address">
          <h4>Shipping to</h4>
          <p>{order.address}, {order.city} &mdash; {order.pincode}</p>
        </div>

        <Link to="/" className="btn btn-primary btn-full">Continue Shopping</Link>
      </div>
    </section>
  );
}
