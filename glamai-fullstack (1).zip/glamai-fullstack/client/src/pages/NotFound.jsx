import { Link } from 'react-router-dom';

export default function NotFound() {
  return (
    <div className="detail-message">
      <p>This feather flew away &mdash; page not found.</p>
      <Link to="/" className="btn btn-primary">Back to Peacock Week</Link>
    </div>
  );
}
