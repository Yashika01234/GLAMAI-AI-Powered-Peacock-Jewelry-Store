import { useEffect, useState } from 'react';
import { api } from '../api.js';
import Hero from '../components/Hero.jsx';
import FilterBar from '../components/FilterBar.jsx';
import ProductGrid from '../components/ProductGrid.jsx';
import { FeatureStrip, StorySection, FaqSection } from '../components/StoryAndFaq.jsx';

export default function Home({ onOpenChat }) {
  const [category, setCategory] = useState('all');
  const [sort, setSort] = useState('featured');
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    api.getProducts({ category, sort })
      .then((data) => { if (!cancelled) setProducts(data); })
      .catch((err) => { if (!cancelled) setError(err.message); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [category, sort]);

  return (
    <>
      <Hero onOpenChat={onOpenChat} />
      <FilterBar category={category} onCategoryChange={setCategory} sort={sort} onSortChange={setSort} />
      <section className="products-section">
        <ProductGrid products={products} loading={loading} error={error} />
      </section>
      <FeatureStrip />
      <StorySection />
      <FaqSection />
    </>
  );
}
