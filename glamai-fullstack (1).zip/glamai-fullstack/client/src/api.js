const BASE = '/api';

export function getCartId() {
  let id = localStorage.getItem('glamai_cart_id');
  if (!id) {
    id = crypto.randomUUID();
    localStorage.setItem('glamai_cart_id', id);
  }
  return id;
}

async function request(path, options = {}) {
  const res = await fetch(`${BASE}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      'X-Cart-Id': getCartId(),
      ...(options.headers || {}),
    },
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || `Request failed: ${res.status}`);
  }
  return res.json();
}

export const api = {
  getProducts: (params = {}) => {
    const qs = new URLSearchParams(params).toString();
    return request(`/products${qs ? `?${qs}` : ''}`);
  },
  getProduct: (id) => request(`/products/${id}`),

  getCart: () => request('/cart'),
  addToCart: (productId, qty = 1) => request('/cart', { method: 'POST', body: JSON.stringify({ productId, qty }) }),
  updateCartQty: (productId, qty) => request(`/cart/${productId}`, { method: 'PATCH', body: JSON.stringify({ qty }) }),
  removeFromCart: (productId) => request(`/cart/${productId}`, { method: 'DELETE' }),
  clearCart: () => request('/cart', { method: 'DELETE' }),

  checkout: (payload) => request('/orders', { method: 'POST', body: JSON.stringify(payload) }),
  getOrder: (id) => request(`/orders/${id}`),

  getChatNodes: () => request('/chat/nodes'),
};
