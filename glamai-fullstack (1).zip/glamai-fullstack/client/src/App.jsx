import { useRef } from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header.jsx';
import { Footer } from './components/StoryAndFaq.jsx';
import CartDrawer from './components/CartDrawer.jsx';
import Chatbot from './components/Chatbot.jsx';
import Home from './pages/Home.jsx';
import ProductDetail from './pages/ProductDetail.jsx';
import Checkout from './pages/Checkout.jsx';
import OrderConfirmation from './pages/OrderConfirmation.jsx';
import NotFound from './pages/NotFound.jsx';

export default function App() {
  const chatRef = useRef(null);

  return (
    <>
      <Header />
      <main>
        <Routes>
          <Route path="/" element={<Home onOpenChat={() => chatRef.current?.open()} />} />
          <Route path="/product/:id" element={<ProductDetail />} />
          <Route path="/checkout" element={<Checkout />} />
          <Route path="/order/:id" element={<OrderConfirmation />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <Footer />
      <CartDrawer />
      <Chatbot ref={chatRef} />
    </>
  );
}
