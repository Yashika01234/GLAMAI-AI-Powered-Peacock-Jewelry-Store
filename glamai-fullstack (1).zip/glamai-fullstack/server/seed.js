import { loadData, saveData } from './db.js';

const PRODUCTS = [
  { id: 'mayil-jhumka', name: 'Mayil Gold Jhumka', category: 'jhumka', variant: 'jhumka', palette: 0, price: 899, orig: 1799,
    desc: 'A classic gold-plated jhumka topped with a hand-etched peacock medallion and a domed bell skirted with beaded drops.' },
  { id: 'nritya-chandbali', name: 'Nritya Peacock Chandbali', category: 'chandbali', variant: 'chandbali', palette: 1, price: 1099, orig: 2199,
    desc: 'A crescent chandbali with a ruby-toned peacock eye at its centre, finished with a soft antique-gold patina.' },
  { id: 'morpankh-stud', name: 'Mor Pankh Studs', category: 'stud', variant: 'stud', palette: 6, price: 399, orig: 799,
    desc: 'Everyday studs shaped like a single peacock feather eye, light enough for all-day wear.' },
  { id: 'kekha-dangler', name: 'Kekha Rosegold Danglers', category: 'dangler', variant: 'dangler', palette: 3, price: 649, orig: 1299,
    desc: 'Rose-gold danglers with a plum enamel peacock crest and a single hanging emerald-toned drop.' },
  { id: 'oxid-jhumka', name: 'Oxidised Peacock Jhumka', category: 'oxidised', variant: 'jhumka', palette: 2, price: 549, orig: 1099,
    desc: 'Oxidised silver jhumka with a turquoise peacock eye and a textured temple-style bell.' },
  { id: 'pankhuri-chand', name: 'Pankhuri Pearl Chandbali', category: 'chandbali', variant: 'chandbali', palette: 4, price: 1299, orig: 2599,
    desc: 'An elaborate chandbali edged in seed pearls, designed for wedding season and festive wear.' },
  { id: 'nilkanth-stud', name: 'Nilkanth Silver Studs', category: 'stud', variant: 'stud', palette: 5, price: 349, orig: 699,
    desc: 'Sterling-finish studs with an emerald-toned peacock eye, minimal enough for the office.' },
  { id: 'rajwada-dangler', name: 'Rajwada Peacock Danglers', category: 'dangler', variant: 'dangler', palette: 7, price: 799, orig: 1599,
    desc: 'Antique-gold danglers with a multicolour enamel crest, inspired by Rajasthani temple jewellery.' },
  { id: 'vintage-jhumka', name: 'Vintage Mor Jhumka', category: 'jhumka', variant: 'jhumka', palette: 7, price: 999, orig: 2299,
    desc: 'Our most detailed jhumka: a layered peacock medallion in ruby and emerald enamel over an antique-gold bell.' },
  { id: 'chandni-dangler', name: 'Chandni Oxidised Danglers', category: 'oxidised', variant: 'dangler', palette: 2, price: 599, orig: 1399,
    desc: 'Long oxidised danglers with a turquoise peacock crest and a single drop bead, catwalk-length.' },
  { id: 'suhana-chand', name: 'Suhana Enamel Chandbali', category: 'chandbali', variant: 'chandbali', palette: 6, price: 1199, orig: 2799,
    desc: 'A statement chandbali in deep blue meenakari enamel, framed in gold with a beaded skirt.' },
  { id: 'kalgi-stud', name: 'Kalgi Pearl Peacock Studs', category: 'stud', variant: 'stud', palette: 4, price: 449, orig: 999,
    desc: 'Gold studs with a pearl-white peacock eye \u2014 soft, bridal-adjacent, and easy to layer with other earrings.' },
];

const data = loadData();

if (data.products.length === 0) {
  data.products = PRODUCTS.map((p) => ({
    id: p.id,
    name: p.name,
    category: p.category,
    variant: p.variant,
    palette: p.palette,
    price: p.price,
    origPrice: p.orig,
    description: p.desc,
    rating: +(4 + (p.price % 10) / 10).toFixed(1),
    reviewCount: 40 + (p.price % 60),
    stock: 15 + (p.price % 20),
  }));
  saveData(data);
  console.log(`Seeded ${data.products.length} products.`);
} else {
  console.log(`Products already seeded (${data.products.length}) \u2014 skipping.`);
}
