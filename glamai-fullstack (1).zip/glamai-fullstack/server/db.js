import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_PATH = path.join(__dirname, 'data.json');

// A tiny JSON-file "database". Deliberately zero-dependency (only Node's
// built-in fs module) so `npm install` never needs to compile a native
// addon -- this keeps setup identical across Windows/Mac/Linux with no
// build tools required. Not meant for concurrent writers / high throughput,
// which is fine for a single-user local demo.

function defaultData() {
  return { products: [], cartItems: [], orders: [] };
}

export function loadData() {
  if (!fs.existsSync(DATA_PATH)) {
    saveData(defaultData());
  }
  try {
    return JSON.parse(fs.readFileSync(DATA_PATH, 'utf-8'));
  } catch {
    return defaultData();
  }
}

export function saveData(data) {
  fs.writeFileSync(DATA_PATH, JSON.stringify(data, null, 2));
}
