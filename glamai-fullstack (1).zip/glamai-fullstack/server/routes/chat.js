import { Router } from 'express';

export const chatRouter = Router();

// A small, fully canned decision tree. No external AI API is called here --
// this endpoint just looks up a node by key, which keeps the assistant
// fast, free, and 100% predictable while still being a real REST call
// the React app talks to (rather than hardcoded client-side strings).
const CHAT_TREE = {
  root: {
    bot: "Namaste! I'm Glam AI, your Peacock Week assistant. What would you like to know?",
    options: [
      { label: 'What is Peacock Week?', next: 'about' },
      { label: "What's the discount?", next: 'discount' },
      { label: 'Shipping & delivery', next: 'shipping' },
      { label: 'Returns & exchange', next: 'returns' },
      { label: 'Track my order', next: 'track' },
      { label: 'Are these real gold?', next: 'material' },
      { label: 'Talk to a human', next: 'human' },
    ],
  },
  about: {
    bot: "Peacock Week is our 7-day festive edit celebrating the peacock's iconic 'mor pankh' \u2014 jhumkas, chandbalis, studs and danglers, all peacock-inspired, all discounted.",
    options: [
      { label: "What's the discount?", next: 'discount' },
      { label: 'Back to menu', next: 'root' },
    ],
  },
  discount: {
    bot: 'Everything in the Peacock Week edit is 40\u201360% off. The badge on each product card shows the exact discount for that piece.',
    options: [
      { label: 'Shipping & delivery', next: 'shipping' },
      { label: 'Back to menu', next: 'root' },
    ],
  },
  shipping: {
    bot: 'We offer free shipping on orders over \u20b9999. Below that, shipping is a flat \u20b979. Standard delivery takes 4\u20136 business days.',
    options: [
      { label: 'Returns & exchange', next: 'returns' },
      { label: 'Back to menu', next: 'root' },
    ],
  },
  returns: {
    bot: 'You can return or exchange any unworn piece within 7 days of delivery, in its original packaging, for a full refund or store credit.',
    options: [
      { label: 'Track my order', next: 'track' },
      { label: 'Back to menu', next: 'root' },
    ],
  },
  track: {
    bot: "Once your order ships, you'll get a tracking link by email. This demo store creates a real order record after checkout \u2014 you can see it on your order confirmation page.",
    options: [
      { label: 'Talk to a human', next: 'human' },
      { label: 'Back to menu', next: 'root' },
    ],
  },
  material: {
    bot: 'Our pieces are crafted in brass and 92.5 silver with gold micron-plating or oxidised finishing, set with kundan, enamel work and cultured pearls \u2014 designed to be tarnish-safe with proper care.',
    options: [
      { label: 'Returns & exchange', next: 'returns' },
      { label: 'Back to menu', next: 'root' },
    ],
  },
  human: {
    bot: 'Our stylists are here Mon\u2013Sat, 10am\u20137pm. In a production build, this button would open live chat or WhatsApp support.',
    options: [
      { label: 'Back to menu', next: 'root' },
    ],
  },
};

// GET /api/chat/nodes  -> the whole tree (used once on first load)
chatRouter.get('/nodes', (req, res) => {
  res.json(CHAT_TREE);
});

// GET /api/chat/nodes/:key -> a single node
chatRouter.get('/nodes/:key', (req, res) => {
  const node = CHAT_TREE[req.params.key];
  if (!node) return res.status(404).json({ error: 'Unknown chat node' });
  res.json(node);
});
