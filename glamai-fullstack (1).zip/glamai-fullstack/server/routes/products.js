import { Router } from 'express';
import { loadData } from '../db.js';

export const productsRouter = Router();

function discountPct(p) {
  return Math.round((1 - p.price / p.origPrice) * 100);
}

function toDTO(p) {
  return { ...p, discountPct: discountPct(p) };
}

// GET /api/products?category=jhumka&sort=discount
productsRouter.get('/', (req, res) => {
  const { category, sort } = req.query;
  const data = loadData();

  let list = data.products;
  if (category && category !== 'all') {
    list = list.filter((p) => p.category === category);
  }
  list = [...list];

  if (sort === 'discount') list.sort((a, b) => discountPct(b) - discountPct(a));
  else if (sort === 'low') list.sort((a, b) => a.price - b.price);
  else if (sort === 'high') list.sort((a, b) => b.price - a.price);

  res.json(list.map(toDTO));
});

// GET /api/products/:id
productsRouter.get('/:id', (req, res) => {
  const data = loadData();
  const product = data.products.find((p) => p.id === req.params.id);
  if (!product) return res.status(404).json({ error: 'Product not found' });
  res.json(toDTO(product));
});
