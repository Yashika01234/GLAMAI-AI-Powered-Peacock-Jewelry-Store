import { Router } from 'express';
import { loadData, saveData } from '../db.js';

export const cartRouter = Router();

// Every request must carry an X-Cart-Id header. The frontend generates
// a random id on first load and stores it in localStorage, so the
// server can keep a per-browser cart without needing user accounts.
cartRouter.use((req, res, next) => {
  const cartId = req.header('x-cart-id');
  if (!cartId) return res.status(400).json({ error: 'Missing X-Cart-Id header' });
  req.cartId = cartId;
  next();
});

function buildCart(data, cartId) {
  const items = data.cartItems
    .filter((ci) => ci.cartId === cartId)
    .map((ci) => {
      const p = data.products.find((pp) => pp.id === ci.productId);
      if (!p) return null;
      return {
        productId: p.id,
        name: p.name,
        price: p.price,
        origPrice: p.origPrice,
        category: p.category,
        variant: p.variant,
        palette: p.palette,
        qty: ci.qty,
      };
    })
    .filter(Boolean);

  const subtotal = items.reduce((sum, i) => sum + i.price * i.qty, 0);
  const count = items.reduce((sum, i) => sum + i.qty, 0);
  return { items, subtotal, count };
}

// GET /api/cart
cartRouter.get('/', (req, res) => {
  const data = loadData();
  res.json(buildCart(data, req.cartId));
});

// POST /api/cart  { productId, qty? }
cartRouter.post('/', (req, res) => {
  const { productId, qty = 1 } = req.body;
  const data = loadData();
  const product = data.products.find((p) => p.id === productId);
  if (!product) return res.status(404).json({ error: 'Product not found' });

  const existing = data.cartItems.find((ci) => ci.cartId === req.cartId && ci.productId === productId);
  if (existing) existing.qty += qty;
  else data.cartItems.push({ cartId: req.cartId, productId, qty });

  saveData(data);
  res.status(201).json(buildCart(data, req.cartId));
});

// PATCH /api/cart/:productId  { qty }
cartRouter.patch('/:productId', (req, res) => {
  const { qty } = req.body;
  if (typeof qty !== 'number') return res.status(400).json({ error: 'qty must be a number' });

  const data = loadData();
  const idx = data.cartItems.findIndex((ci) => ci.cartId === req.cartId && ci.productId === req.params.productId);

  if (qty <= 0) {
    if (idx !== -1) data.cartItems.splice(idx, 1);
  } else if (idx !== -1) {
    data.cartItems[idx].qty = qty;
  }

  saveData(data);
  res.json(buildCart(data, req.cartId));
});

// DELETE /api/cart/:productId
cartRouter.delete('/:productId', (req, res) => {
  const data = loadData();
  data.cartItems = data.cartItems.filter((ci) => !(ci.cartId === req.cartId && ci.productId === req.params.productId));
  saveData(data);
  res.json(buildCart(data, req.cartId));
});

// DELETE /api/cart  (clear everything, used after checkout)
cartRouter.delete('/', (req, res) => {
  const data = loadData();
  data.cartItems = data.cartItems.filter((ci) => ci.cartId !== req.cartId);
  saveData(data);
  res.json(buildCart(data, req.cartId));
});
