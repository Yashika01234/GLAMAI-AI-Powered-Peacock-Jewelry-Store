import { Router } from 'express';
import { randomUUID } from 'node:crypto';
import { loadData, saveData } from '../db.js';

export const ordersRouter = Router();

const FREE_SHIPPING_THRESHOLD = 999;
const SHIPPING_FEE = 79;

// POST /api/orders  { customerName, email, address, city, pincode }
ordersRouter.post('/', (req, res) => {
  const cartId = req.header('x-cart-id');
  if (!cartId) return res.status(400).json({ error: 'Missing X-Cart-Id header' });

  const { customerName, email, address, city, pincode } = req.body;
  if (!customerName || !email || !address || !city || !pincode) {
    return res.status(400).json({ error: 'All fields are required' });
  }

  const data = loadData();
  const cartItems = data.cartItems.filter((ci) => ci.cartId === cartId);
  if (cartItems.length === 0) {
    return res.status(400).json({ error: 'Cart is empty' });
  }

  const items = cartItems.map((ci) => {
    const p = data.products.find((pp) => pp.id === ci.productId);
    return { productId: ci.productId, name: p.name, price: p.price, qty: ci.qty };
  });

  const subtotal = items.reduce((s, i) => s + i.price * i.qty, 0);
  const shipping = subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : SHIPPING_FEE;
  const total = subtotal + shipping;

  const order = {
    id: randomUUID(),
    cartId,
    customerName,
    email,
    address,
    city,
    pincode,
    subtotal,
    shipping,
    total,
    items,
    createdAt: new Date().toISOString(),
  };

  data.orders.push(order);
  data.cartItems = data.cartItems.filter((ci) => ci.cartId !== cartId);
  saveData(data);

  res.status(201).json(order);
});

// GET /api/orders/:id
ordersRouter.get('/:id', (req, res) => {
  const data = loadData();
  const order = data.orders.find((o) => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found' });
  res.json(order);
});
